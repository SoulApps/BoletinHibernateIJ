package EJ8;

import Utils.HibernateUtils;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        /*Dado un curso concreto, mostrar el nombre del tutor y todos los datos de sus asignaturas.
(Utilizar array de objetos).*/

    }
}
